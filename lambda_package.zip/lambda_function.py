import json
import boto3
import base64
from urllib.parse import unquote
from security_utils import encrypt_aes_512, decrypt_aes_512

# ========== CONFIGURATION ==========
BUCKET = "mon-bucket-s3-reel"  # 🔴 REMPLACEZ PAR VOTRE VRAI BUCKET S3

CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
}

def escape_html(text: str) -> str:
    """Échappe les caractères HTML dangereux"""
    return (text.replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&#39;'))

def escape_url(text: str) -> str:
    """Échappe pour une URL"""
    import urllib.parse
    return urllib.parse.quote(text, safe='')

# ========== HANDLER PRINCIPAL ==========
def lambda_handler(event, context):
    try:
        s3 = boto3.client('s3')
        
        # Récupérer la méthode HTTP
        method = event.get('httpMethod', 'GET').upper()
        
        # === GESTION OPTIONS (CORS preflight) ===
        if method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': ''
            }
        
        # Récupérer les paramètres
        params = event.get('queryStringParameters') or {}
        
        print(f"DEBUG: method={method}, params={params}")
        
        # === 1. GET - CONSULTATION ===
        if method == 'GET' and params and 'file' in params:
            file_key = unquote(params['file'])
            try:
                response = s3.get_object(Bucket=BUCKET, Key=file_key)
                raw = response['Body'].read()
                decrypted, error = decrypt_aes_512(raw)
                
                if error:
                    display_text = "ACCES REFUSE\n\n" + error
                else:
                    try:
                        display_text = decrypted.decode('utf-8')
                    except UnicodeDecodeError:
                        display_text = "Fichier binaire dechiffre avec succes.\nTaille : " + str(len(decrypted)) + " octets"

                # Échapper le nom du fichier pour HTML
                safe_filename = escape_html(file_key.split('/')[-1])
                safe_display_text = escape_html(display_text)

                html_body = f"""<!DOCTYPE html><html lang="fr">
<head><meta charset="UTF-8">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
body {{ font-family:'Inter',sans-serif; background:#0f172a; color:white; margin:0; display:flex; justify-content:center; align-items:center; min-height:100vh; }}
.box {{ width:90%; max-width:800px; background:rgba(30,41,59,0.7); backdrop-filter:blur(12px); border:1px solid rgba(255,255,255,0.1); border-radius:24px; padding:40px; box-shadow:0 25px 50px rgba(0,0,0,0.5); }}
pre {{ background:rgba(0,0,0,0.3); padding:20px; border-radius:16px; border:1px solid rgba(255,255,255,0.1); color:#38bdf8; white-space:pre-wrap; font-family:monospace; overflow-x:auto; }}
.back {{ color:#38bdf8; text-decoration:none; font-weight:600; margin-bottom:20px; display:inline-block; }}
.badge {{ display:inline-block; padding:6px 12px; border-radius:20px; background:rgba(16,185,129,0.1); color:#10b981; font-size:12px; font-weight:600; border:1px solid rgba(16,185,129,0.2); }}
</style></head>
<body><div class="box">
<a href="?" class="back">← Retour au Drive</a>
<h2>{safe_filename}</h2>
<div class="badge">Dechiffre AES-512 double couche</div><br><br>
<pre>{safe_display_text}</pre>
</div></body></html>"""

                return {
                    'statusCode': 200,
                    'headers': {'Content-Type': 'text/html; charset=utf-8'},
                    'body': html_body
                }
            except Exception as e:
                return {
                    'statusCode': 404,
                    'headers': CORS_HEADERS,
                    'body': json.dumps({'error': 'Fichier non trouve', 'details': str(e)})
                }

        # === 2. POST - UPLOAD ===
        if method == 'POST':
            print(f"DEBUG: POST request - body length: {len(event.get('body', ''))}")
            try:
                # Gérer le body encodé en base64 par API Gateway
                body_str = event.get('body', '{}')
                if event.get('isBase64Encoded', False):
                    print("DEBUG: Decoding base64 body")
                    body_str = base64.b64decode(body_str).decode('utf-8')
                
                print(f"DEBUG: Parsing JSON - body_str length: {len(body_str)}")
                body = json.loads(body_str)
                filename = body.get('filename', 'file.bin')
                content_b64 = body.get('base64Data', '')
                
                print(f"DEBUG: filename={filename}, base64 length={len(content_b64)}")
                
                if not content_b64:
                    print("DEBUG: No base64 data provided")
                    return {
                        'statusCode': 400,
                        'headers': CORS_HEADERS,
                        'body': json.dumps({'status': 'ERROR', 'details': 'Pas de donnees base64'})
                    }
                
                print("DEBUG: Decoding base64 data")
                raw_data = base64.b64decode(content_b64)
                print(f"DEBUG: Encrypting data - size: {len(raw_data)}")
                payload, signature = encrypt_aes_512(raw_data)
                encrypted_body = signature + payload  # Signature en premier
                print(f"DEBUG: Encrypted size: {len(encrypted_body)}, uploading to S3")
                
                s3.put_object(
                    Bucket=BUCKET,
                    Key="logs_authentification/AES512_" + filename,
                    Body=encrypted_body
                )
                
                print("DEBUG: Upload successful")
                return {
                    'statusCode': 200,
                    'headers': CORS_HEADERS,
                    'body': json.dumps({
                        'status': 'SUCCESS',
                        'encryption': 'AES-512 double layer + HMAC-SHA512'
                    })
                }
            except json.JSONDecodeError as e:
                print(f"DEBUG: JSON error: {str(e)}")
                return {
                    'statusCode': 400,
                    'headers': CORS_HEADERS,
                    'body': json.dumps({'status': 'ERROR', 'details': f'JSON invalide: {str(e)}'})
                }
            except Exception as e:
                import traceback
                error_msg = str(e)
                tb = traceback.format_exc()
                print(f"DEBUG: Exception in POST: {error_msg}\n{tb}")
                return {
                    'statusCode': 500,
                    'headers': CORS_HEADERS,
                    'body': json.dumps({
                        'status': 'ERROR',
                        'details': error_msg,
                        'errorType': type(e).__name__
                    })
                }
        
        # Safety check - POST should always return above
        if method == 'POST':
            return {
                'statusCode': 500,
                'headers': CORS_HEADERS,
                'body': json.dumps({'status': 'ERROR', 'details': 'POST reached unexpected code path'})
            }

        # === 3. GET - LISTE DES FICHIERS ===
        print("DEBUG: Generating file list HTML")
        file_list_html = ""
        try:
            print(f"DEBUG: Listing S3 objects from bucket={BUCKET}, prefix=logs_authentification/")
            res = s3.list_objects_v2(Bucket=BUCKET, Prefix="logs_authentification/")
            files = res.get('Contents', [])
            print(f"DEBUG: Found {len(files)} objects in S3")
            if files:
                for obj in files:
                    name = obj['Key']
                    if name.endswith('/'):
                        continue
                    display_name = escape_html(name.split('/')[-1])
                    size = round(obj['Size'] / 1024, 1)
                    url_name = escape_url(name)
                    file_list_html += (
                        '<div class="file-card">'
                        '<div class="file-info">'
                        '<span class="file-icon">📄</span>'
                        '<div class="file-details">'
                        f'<span class="file-name">{display_name}</span>'
                        f'<span class="file-meta">{str(size)} Ko • Chiffre AES-512</span>'
                        '</div></div>'
                        f'<a href="?file={url_name}" class="btn-action">Consulter</a>'
                        '</div>'
                    )
            else:
                file_list_html = '<div style="text-align:center;color:#94a3b8;padding:20px;">📭 Aucun fichier sécurisé.<br><small>Téléchargez-en un pour commencer.</small></div>'
            print("DEBUG: File list generated successfully")
        except Exception as e:
            error_msg = str(e)
            print(f"ERROR: S3 list failed: {error_msg}")
            # Return JSON error instead of HTML
            return {
                'statusCode': 500,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'status': 'ERROR',
                    'details': f'Erreur S3: {error_msg}',
                    'bucket': BUCKET,
                    'errorType': type(e).__name__
                })
            }

        html_page = """<!DOCTYPE html>
<html lang="fr"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CloudVault | AES-512</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<style>
:root { --bg:#0f172a; --card-bg:rgba(30,41,59,0.7); --primary:#38bdf8; --success:#10b981; --text:#f8fafc; --border:rgba(255,255,255,0.1); }
body { font-family:'Inter',sans-serif; background-color:var(--bg); background-image:radial-gradient(circle at top right,#1e293b,#0f172a); color:var(--text); margin:0; display:flex; justify-content:center; align-items:center; min-height:100vh; }
.app-container { width:90%; max-width:800px; background:var(--card-bg); backdrop-filter:blur(12px); border:1px solid var(--border); border-radius:24px; padding:40px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); }
header { text-align:center; margin-bottom:40px; }
h1 { font-size:28px; font-weight:600; margin:0; background:linear-gradient(to right,#7bdcff,var(--primary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
.status-badge { display:inline-block; padding:6px 12px; border-radius:20px; background:rgba(16,185,129,0.1); color:var(--success); font-size:12px; font-weight:600; margin-top:10px; border:1px solid rgba(16,185,129,0.2); }
.file-list { margin-top:20px; max-height:350px; overflow-y:auto; padding-right:10px; }
.file-card { background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:16px; padding:16px; display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; transition:all 0.3s ease; }
.file-card:hover { transform:translateY(-2px); background:rgba(255,255,255,0.06); border-color:var(--primary); }
.file-info { display:flex; align-items:center; }
.file-icon { font-size:24px; margin-right:15px; }
.file-details { display:flex; flex-direction:column; }
.file-name { font-weight:600; font-size:14px; color:white; }
.file-meta { font-size:11px; color:#94a3b8; }
.btn-action { background:transparent; border:1px solid var(--primary); color:var(--primary); padding:8px 16px; border-radius:8px; cursor:pointer; font-size:12px; font-weight:600; transition:0.3s; text-decoration:none; }
.btn-action:hover { background:var(--primary); color:#000; }
.upload-zone { margin-top:30px; padding:30px; border:2px dashed var(--border); border-radius:20px; text-align:center; }
.btn-main { background:var(--primary); color:#0f172a; border:none; padding:12px 24px; border-radius:12px; font-weight:600; cursor:pointer; width:100%; box-shadow:0 10px 15px rgba(56,189,248,0.3); transition:all 0.3s ease; }
.btn-main:hover { transform:translateY(-2px); background:#7bdcff; box-shadow:0 20px 25px rgba(56,189,248,0.5); }
input[type="file"] { color:#94a3b8; font-size:13px; margin-bottom:20px; }
#st { font-size:13px; margin-top:15px; color:var(--primary); font-weight:bold; }
::-webkit-scrollbar { width:6px; }
::-webkit-scrollbar-thumb { background:var(--border); border-radius:10px; }
</style>
</head>
<body><div class="app-container">
<header>
<h1>Mon Coffre-Fort Cloud</h1>
<div class="status-badge">● Chiffrement AES-512 Actif</div>
</header>
<div class="file-list">""" + file_list_html + """</div>
<div class="upload-zone">
<p style="margin-top:0;font-size:14px;color:#94a3b8;">Securiser un nouveau document</p>
<input type="file" id="f"><br>
<button onclick="up()" class="btn-main">🚀 Archiver sur AWS (AES-512)</button>
<div id="st"></div>
</div>
</div>
<script>
async function up() {
    const f = document.getElementById('f').files[0];
    const st = document.getElementById('st');
    if (!f) return alert("Selectionnez un fichier");
    st.innerText = "⏳ Chiffrement AES-512 et transfert...";
    const reader = new FileReader();
    reader.onload = async function() {
        const b64 = reader.result.split(',')[1];
        try {
            const res = await fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ filename: f.name, base64Data: b64 })
            });
            
            const contentType = res.headers.get('content-type') || '';
            let data = {};
            
            if (contentType.includes('application/json')) {
                data = await res.json();
            } else {
                const text = await res.text();
                console.error("Response is not JSON. Content-Type:", contentType);
                console.error("Response body:", text.substring(0, 500));
                st.innerHTML = "❌ Erreur serveur (réponse non JSON)<br>" +
                    "<small>Content-Type: " + contentType + "</small><br>" +
                    "<small>Vérifiez CloudWatch Logs (Lambda)</small>";
                return;
            }
            
            if (res.ok && data.status === 'SUCCESS') {
                st.innerText = "✅ Archive avec succes (AES-512) !";
                document.getElementById('f').value = '';
                setTimeout(() => location.reload(), 1500);
            } else { 
                st.innerText = "❌ " + (data.details || data.error || 'Erreur inconnue');
                console.error("Response data:", data);
            }
        } catch(e) { 
            st.innerText = "❌ Erreur: " + e.message; 
            console.error("Erreur fetch:", e);
        }
    };
    reader.readAsDataURL(f);
}
</script>
</body></html>"""

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html; charset=utf-8'},
            'body': html_page
        }

    except Exception as e:
        import traceback
        error_msg = str(e)
        tb = traceback.format_exc()
        print(f"FATAL ERROR: {error_msg}\n{tb}")
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'status': 'ERROR',
                'details': error_msg,
                'bucket': BUCKET,
                'errorType': type(e).__name__
            })
        }
